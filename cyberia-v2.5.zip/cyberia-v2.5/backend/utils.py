"""Generic helpers for file and data handling in the Cyberia backend."""

from __future__ import annotations

import json
import os
import re
from typing import Any, Dict

from paths import backend_path


def read_text(path: str) -> str:
    try:
        with open(path, "r", encoding="utf-8") as handle:
            return handle.read()
    except Exception:
        return ""


def write_text(path: str, text: str) -> None:
    with open(path, "w", encoding="utf-8") as handle:
        handle.write(text)


def read_json(path: str) -> Dict[str, Any]:
    try:
        with open(path, "r", encoding="utf-8") as handle:
            return json.load(handle)
    except Exception:
        return {}


def normalize_manifest_text(text: str) -> str:
    content = (text or "").strip()
    if not content:
        return content

    content = re.sub(r",\s*]", "]", content)
    content = re.sub(r",\s*}\s*$", "}", content)

    if (
        content.startswith('"api_list"')
        or content.startswith("'api_list'")
        or content.startswith("api_list")
    ):
        if not content.startswith("{"):
            content = "{" + content
        if not content.endswith("}"):
            content = content.rstrip(",") + "}"

    try:
        json.loads(content)
        return content
    except Exception:
        return text


def ensure_temp_download_dir() -> str:
    root = backend_path("temp_dl")
    try:
        os.makedirs(root, exist_ok=True)
    except Exception:
        pass
    return root


def get_accela_api_key() -> str:
    """
    Attempts to read the Morrenus API key from ACCELA's config file.
    Returns empty string if file is not found or key is not present.
    """
    import configparser

    config_path = os.path.expanduser("~/.config/Tachibana Labs/ACCELA.conf")

    if not os.path.exists(config_path):
        return ""

    try:
        config = configparser.ConfigParser()
        config.read(config_path)

        # Check if General section exists (ACCELA.conf uses [General] section)
        if not config.has_section("General"):
            return ""

        # Try common key names for the Morrenus API key
        possible_keys = ["morrenus_api_key"]

        for key in possible_keys:
            if config.has_option("General", key):
                value = config.get("General", key)
                if value:
                    return str(value)

        # If not found, search for any key containing "morrenus" in its name
        for key in config.options("General"):
            if "morrenus" in key.lower():
                value = config.get("General", key)
                if value:
                    return str(value)

        return ""
    except Exception:
        return ""


__all__ = [
    "ensure_temp_download_dir",
    "get_accela_api_key",
    "normalize_manifest_text",
    "read_json",
    "read_text",
    "write_text",
]
