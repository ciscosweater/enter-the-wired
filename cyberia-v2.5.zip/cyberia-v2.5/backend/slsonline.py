import json
import os
import re

import httpx
from logger import logger
from ruamel.yaml import YAML
from ruamel.yaml.comments import CommentedMap
from ruamel.yaml.scalarstring import DoubleQuotedScalarString




def _get_slssteam_config_path() -> str:
    return os.path.expanduser("~/.config/SLSsteam/config.yaml")


def _get_game_name(appid: int) -> str:
    """Get game name from Steam Store API."""
    try:
        url = f"https://store.steampowered.com/api/appdetails?appids={appid}"
        with httpx.Client(timeout=10.0) as client:
            response = client.get(url)
            response.raise_for_status()
            data = response.json()
            if str(appid) in data and data[str(appid)].get("success"):
                return data[str(appid)]["data"].get("name", "")
    except Exception as exc:
        logger.warning(f"Failed to get game name for appid {appid}: {exc}")
    return ""


def _update_fake_app_ids(content: str, fake_app_ids: dict) -> str:
    lines = content.split('\n')
    result = []
    i = 0

    while i < len(lines):
        line = lines[i]

        if line.strip().startswith('FakeAppIds:'):
            result.append(line)
            i += 1

            while i < len(lines):
                current = lines[i]
                indent = len(current) - len(current.lstrip())

                if current.strip() == '':
                    # Skip empty lines within FakeAppIds section
                    i += 1
                    continue

                indent_current = len(current) - len(current.lstrip())
                if indent_current <= 0:
                    break

                if re.match(r'^\s*\d+:\s*\d+', current):
                    i += 1
                    continue

                result.append(current)
                i += 1

            for appid, (steamid, comment) in fake_app_ids.items():
                if comment:
                    result.append(' ' * 2 + f"{appid}: {steamid}   # {comment}")
                else:
                    result.append(' ' * 2 + f"{appid}: {steamid}")

            if fake_app_ids:
                result.append('')
        else:
            result.append(line)
            i += 1

    return '\n'.join(result)


def _update_status_section(content: str, section_name: str, updates: dict) -> str:
    lines = content.split('\n')
    result = []
    i = 0

    while i < len(lines):
        line = lines[i]

        if line.strip().startswith(f'{section_name}:'):
            result.append(line)
            i += 1

            section_indent = len(line) - len(line.lstrip())
            found_appid = False
            found_title = False

            while i < len(lines):
                current = lines[i]
                indent = len(current) - len(current.lstrip())

                if current.strip() == '':
                    result.append(current)
                    i += 1
                    continue

                if indent <= section_indent:
                    break

                if 'AppId:' in current:
                    found_appid = True
                    if 'AppId' in updates:
                        appid_value = updates['AppId']
                        result.append(' ' * (section_indent + 2) + f"AppId: {appid_value}")
                    i += 1
                elif 'Title:' in current:
                    found_title = True
                    if 'Title' in updates:
                        title_value = updates['Title']
                        if '"' not in str(title_value) and "'" not in str(title_value):
                            title_value = f'"{title_value}"'
                        result.append(' ' * (section_indent + 2) + f"Title: {title_value}")
                    i += 1
                else:
                    result.append(current)
                    i += 1

            if not found_appid and 'AppId' in updates:
                result.append(' ' * (section_indent + 2) + f"AppId: {updates['AppId']}")
            if not found_title and 'Title' in updates:
                title_value = updates['Title']
                if '"' not in str(title_value) and "'" not in str(title_value):
                    title_value = f'"{title_value}"'
                result.append(' ' * (section_indent + 2) + f"Title: {title_value}")
        else:
            result.append(line)
            i += 1

    return '\n'.join(result)




def check_fake_app_id(appid: int) -> str:
    try:
        config_path = _get_slssteam_config_path()
        if not os.path.exists(config_path):
            return json.dumps({"success": True, "exists": False})

        yaml = YAML()
        yaml.preserve_quotes = True
        yaml.width = 4096

        with open(config_path, "r") as f:
            config = yaml.load(f)

        fake_app_ids = config.get("FakeAppIds") or {}
        exists = appid in fake_app_ids
        return json.dumps({"success": True, "exists": exists})
    except Exception as exc:
        logger.error(f"Error checking FakeAppId: {exc}")
        return json.dumps({"success": False, "error": str(exc)})


def toggle_fake_app_id(appid: int) -> str:
    try:
        config_path = _get_slssteam_config_path()
        if not os.path.exists(config_path):
            return json.dumps({"success": False, "error": "Config file not found"})

        with open(config_path, "r") as f:
            content = f.read()

        # Check if appid already exists in FakeAppIds
        appid_pattern = re.compile(rf'^\s*{appid}\s*:\s*\d+', re.MULTILINE)
        existing_match = appid_pattern.search(content)

        if existing_match:
            # Remove existing entry - find the full line and remove it
            line_start = existing_match.start()
            line_end = content.find('\n', line_start)
            if line_end == -1:
                line_end = len(content)

            # Remove trailing blank line if present
            while line_end < len(content) and content[line_end] == '\n':
                next_char = content[line_end + 1] if line_end + 1 < len(content) else ''
                if next_char and not next_char.isspace() and next_char != '\n':
                    break
                line_end += 1

            new_content = content[:line_start] + content[line_end:]
            action = "removed"
        else:
            # Add new entry - find FakeAppIds section
            fake_appids_pattern = re.compile(r'^FakeAppIds:', re.MULTILINE)
            match = fake_appids_pattern.search(content)

            if match:
                # Find end of section (first line that's not indented, not empty, not comment)
                section_start = match.end()
                lines = content[section_start:].split('\n')

                insert_pos = section_start
                i = 0
                while i < len(lines):
                    line = lines[i]
                    stripped = line.strip()

                    # Skip empty lines and comments
                    if not stripped or stripped.startswith('#'):
                        i += 1
                        continue

                    # Check if we hit a non-entry line (not indented)
                    if stripped and not line.startswith(' ') and not line.startswith('\t'):
                        break

                    # This is an entry line
                    if re.match(r'^\s*\d+\s*:', line):
                        # Update position to after this line
                        insert_pos = section_start + sum(len(lines[j]) + 1 for j in range(i + 1))
                    i += 1

                # Build new entry
                game_name = _get_game_name(appid)
                comment = f"   # {game_name} -> Spacewar" if game_name else ""
                new_entry = f"  {appid}: 480{comment}\n"

                new_content = content[:insert_pos] + new_entry + content[insert_pos:]
            else:
                # No FakeAppIds section, create it
                game_name = _get_game_name(appid)
                comment = f"   # {game_name} -> Spacewar" if game_name else ""
                new_entry = f"\nFakeAppIds:\n  {appid}: 480{comment}\n"
                new_content = content + new_entry

            action = "added"

        with open(config_path, "w") as f:
            f.write(new_content)

        logger.log(f"FakeAppId {appid} {action}")
        return json.dumps({"success": True, "action": action, "appid": appid})
    except Exception as exc:
        logger.error(f"Error toggling FakeAppId: {exc}")
        return json.dumps({"success": False, "error": str(exc)})


def get_status_config() -> str:
    try:
        config_path = _get_slssteam_config_path()
        if not os.path.exists(config_path):
            return json.dumps(
                {
                    "success": True,
                    "idle_appid": 0,
                    "idle_title": "",
                    "unowned_appid": 0,
                    "unowned_title": "",
                }
            )

        yaml = YAML()
        yaml.preserve_quotes = True
        yaml.width = 4096

        with open(config_path, "r") as f:
            config = yaml.load(f)

        idle_status = config.get("IdleStatus") or {}
        unowned_status = config.get("UnownedStatus") or {}

        return json.dumps(
            {
                "success": True,
                "idle_appid": idle_status.get("AppId", 0),
                "idle_title": idle_status.get("Title", ""),
                "unowned_appid": unowned_status.get("AppId", 0),
                "unowned_title": unowned_status.get("Title", ""),
            }
        )
    except Exception as exc:
        logger.error(f"Error reading status config: {exc}")
        return json.dumps({"success": False, "error": str(exc)})


def save_status_config(
    idle_appid: int, idle_title: str, unowned_appid: int, unowned_title: str
) -> str:
    try:
        config_path = _get_slssteam_config_path()
        if not os.path.exists(config_path):
            return json.dumps({"success": False, "error": "Config file not found"})

        with open(config_path, "r") as f:
            content = f.read()

        updated_content = _update_status_section(content, "IdleStatus", {
            "AppId": idle_appid,
            "Title": idle_title
        })

        updated_content = _update_status_section(updated_content, "UnownedStatus", {
            "AppId": unowned_appid,
            "Title": unowned_title
        })

        with open(config_path, "w") as f:
            f.write(updated_content)

        logger.log("Status config saved")
        return json.dumps({"success": True})
    except Exception as exc:
        logger.error(f"Error saving status config: {exc}")
        return json.dumps({"success": False, "error": str(exc)})
